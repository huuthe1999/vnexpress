import { ReactComponent as HeartIcon } from './logo.svg';
const imgStory = require('./img-story.jpg');
const authorStory = require('./author.png');
const advStory = require('./adver.jpg');
const newsImg = require('./newsImg.png');
const cardsImg = require('./card.jpg');
export { HeartIcon, imgStory, authorStory, advStory, newsImg, cardsImg };
